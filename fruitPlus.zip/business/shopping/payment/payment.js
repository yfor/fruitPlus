define(["amaze","wx","framework/services/shoppingService"],function (amaze,wx,shopList){
	var ctrl = ["$scope","$state","orderList","$q",function($scope,$state,orderList,$q){
	}]
	return ctrl;
});
